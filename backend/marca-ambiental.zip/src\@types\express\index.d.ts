declare namespace Express {
    export interface Request {
        user_id: number;
        area_id: number;
    }
}